const express = require('express');
const controller = require('../controller/driverController');

const router = express.Router();

router.get('/driverLogin', controller.driverLogin);
router.post('/driverLogin', controller.driverLoginPost);
router.get('/driverRegister', controller.driverRegister);
router.post('/driverRegister', controller.driverRegisterPost);
router.get('/driverHome', controller.driverHome);


module.exports = router;