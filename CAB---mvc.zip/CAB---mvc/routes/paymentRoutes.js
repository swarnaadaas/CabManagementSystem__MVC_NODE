const express = require('express');
const controllers = require('../controller/paymentController');

const router = express.Router();

router.get('/payment/:id', controllers.paymentCreate);
router.post('/payment', controllers.paymentCreatePost);
router.get('/paymentInvoice', controllers.paymentInvoice);


module.exports = router;