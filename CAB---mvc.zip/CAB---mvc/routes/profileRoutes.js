const express = require('express');
const controllers = require('../controller/profileController');

const router = express.Router();

router.get('/profileIndex', controllers.profileIndex);
router.get('/profileUpdate/:p_id', controllers.profileUpdate);
router.post('/profileUpdate/:p_id', controllers.profileUpdatePost);
router.get('/profileDelete/:p_id', controllers.profileDelete);


module.exports = router;