const express = require('express');
const controllers = require('../controller/driverProfileController');

const router = express.Router();

router.get('/driverProfileIndex', controllers.driverProfileIndex);
router.get('/driverProfileUpdate/:d_id', controllers.driverProfileUpdate);
router.post('/driverProfileUpdate/:d_id', controllers.driverProfileUpdatePost);
router.get('/driverProfileDelete/:d_id', controllers.driverProfileDelete);

module.exports = router;
