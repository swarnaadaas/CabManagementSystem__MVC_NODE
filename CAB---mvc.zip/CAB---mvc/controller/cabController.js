const {Cab, Driver} = require('../model/model');

module.exports.index = (req, res, next) => {
    Cab.findAll().then(cabs => {
        res.render('cab-index', {
            data: cabs,
            identity: req.identity.admin
        });
    });
}

module.exports.create = (req, res, next) => {
    Driver.findAll().then((driver)=>{
        console.log(driver)
        res.render('cab-create', {
            driver_name : driver
        })
    })
};

module.exports.createPost = (req, res, next) => {
    var temp = req.body.driver_name;
    var new_temp = temp.split(':');

    Cab.create({
        cabNo: req.body.cab_no,
        cabType: req.body.cab_type,
        cabCapacity: req.body.cab_capacity,
        driverDId : new_temp[1]
    })
        .then(cabFromDb => {
            res.redirect("/index");
        })
}

module.exports.update = async (req, res, next) => {
    Cab.findByPk(req.params.c_id)
        .then(cabFromDb => {
            res.render('cab-update', {
                data: cabFromDb
            });
        });
}


module.exports.updatePost = async (req, res, next) => {
    await Cab.update(
        {
            cabNo: req.body.cab_no,
            cabType: req.body.cab_type,
            cabCapacity: req.body.cab_capacity,
        },
        {
            where: { c_id: req.params.c_id }
        }
    )
    res.redirect('/index');
}

module.exports.delete = async (req, res, next) => {
    let c_id = req.params.c_id;
    let cabFromDb = await Cab.findByPk(c_id);
    if (cabFromDb != null) {
        await Cab.destroy({
            where: {
                c_id: c_id
            }
        });
        res.redirect("/index");
    }
}