const {Booking, Cab, Passenger, Place, Driver} = require('../model/model');

module.exports.bookingIndex = (req, res, next) => {
    console.log(req.session)
    Booking.findAll({where:{PassengerPId: req.session.passengerId}}).then(bookings => {
        res.render('booking-index', {
            data: bookings,
            identity: req.identity.passenger
        });
    })
}

module.exports.pBookings = (req, res, next) => {
    console.log(req.session)
    Booking.findAll({where:{PassengerPId: req.session.passengerId}}).then(bookings => {
        res.render('driverBooking-index', {
            data: bookings,
            identity: req.identity.passenger
        });
    })
}

module.exports.bookingCreate = (req, res, next) => {
    Place.findAll({
    distinct: true
    }
        
    ).then(placeDetails=>{
        
        res.render('booking-create', {data: placeDetails});
    })

    }


module.exports.bookingCreatePost = (req, res, next)=>{
    // Place.findByPk(req.params.place_id).then((data)=>{
        Place.findOne(
            {where:{
                pick:req.body.pick,
                drop: req.body.drop
            }}
        ).then((fareDetails)=>{
            console.log(fareDetails);

            Booking.create({
                pick: req.body.pick,
                drop: req.body.drop,
                cabType: req.body.cab_type,
                pickDate: req.body.pick_date, 
                pickTime: req.body.pick_time, 
                // c_id: req.params.c_id, 
                cost: fareDetails.cost,
                // place_id: fareDetails.place_id,
                // p_id: req.session.passengerId, 
                // place_id: new_temp1[1],
                // d_id: data.d_id
                passengerId: 1
            }).then(dataFromDB=>{
                res.redirect('/payment/'+dataFromDB.b_id)
            })
        }) 
    }
// module.exports.bookingCreatePost = (req, res, next) => {
//     tbl_booking.create({
//             pick: req.body.pick,
//             drop: req.body.drop,
//             cabType: req.body.cab_type,
//             pickDate: req.body.pick_date,
//             pickTime: req.body.pick_time,
//             p_id: req.body.p_id
//         })
//         .then(bookingFromDb => {
//             res.redirect("/bookingIndex");
//         })  
// }
module.exports.bookingUpdate = async(req, res, next) => {
    Booking.findByPk(req.params.b_id)
        .then(bookingFromDb => {
            res.render('booking-update', {
                data: bookingFromDb
            });
        });
}


module.exports.bookingUpdatePost = async (req, res, next) => {
    await Booking.update(
        {
            pick: req.body.pick,
            drop: req.body.drop,
            cabType: req.body.cab_type,
            pickDate: req.body.pick_date,
            pickTime: req.body.pick_time
        },
        {
            where: {b_id: req.params.b_id}
        }
    )
    res.redirect('/bookingIndex');
}

module.exports.bookingDelete = async (req, res, next) => {
    let b_id = req.params.b_id;
    let bookingFromDb = await Booking.findByPk(b_id);
    if (bookingFromDb != null) {
        await Booking.destroy({
            where: {
                b_id: b_id
            }
        });
        res.redirect("/bookingIndex");
    }
}