const {Place} = require('../model/model');

module.exports.placeIndex = (req, res, next) => {
    Place.findAll().then(cabs => {
        res.render('place-index');
    });
}

module.exports.placeCreate = (req, res, next) => {
    res.render('place');
}
module.exports.placeCreatePost = async (req, res, next) => {
    Place.create({
        pick: req.body.pick,
        drop: req.body.drop,
        cost: req.body.cost
    }).then(
        res.redirect('/placeIndex')    )
}


// module.exports.update = async (req, res, next) => {
//     Cab.findByPk(req.params.c_id)
//         .then(cabFromDb => {
//             res.render('cab-update', {
//                 data: cabFromDb
//             });
//         });
// }


// module.exports.updatePost = async (req, res, next) => {
//     await Cab.update(
//         {
//             cabNo: req.body.cab_no,
//             cabType: req.body.cab_type,
//             cabCapacity: req.body.cab_capacity,
//         },
//         {
//             where: { c_id: req.params.c_id }
//         }
//     )
//     res.redirect('/index');
// }

// module.exports.delete = async (req, res, next) => {
//     let c_id = req.params.c_id;
//     let cabFromDb = await Cab.findByPk(c_id);
//     if (cabFromDb != null) {
//         await Cab.destroy({
//             where: {
//                 c_id: c_id
//             }
//         });
//         res.redirect("/index");
//     }
// }