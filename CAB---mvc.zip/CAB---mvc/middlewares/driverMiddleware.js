const driver = require('../model/driver');

module.exports = async (req, res, next) => {
    req.identity = {
        isAuthenticated: false,
        driver: null
    }

    if (req.url == "/driverLogin" || req.url == "/driverRegister") {
        return next();
    }

    let driverId = req.session.driverId;
    if (!driverId || driverId == null) {
        return res.redirect("/driverLogin");
    }

    let driverFromDb = await driver.findByPk(driverId);
    if (driverFromDb == null) {
        return res.redirect("/driverLogin");
    }

    req.identity.isAuthenticated = true;
    req.identity.driver = {
        d_id: driverFromDb.dataValues.d_id,
        name: driverFromDb.dataValues.name,
        email: driverFromDb.dataValues.email,
        license_no: driverFromDb.dataValues.license_no,
        phone: driverFromDb.dataValues.phone,
        role: 'driver'
    }
    next();
}